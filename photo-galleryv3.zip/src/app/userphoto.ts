export interface UserPhoto {
 filePath: string;
 webviewPath: string;
}
